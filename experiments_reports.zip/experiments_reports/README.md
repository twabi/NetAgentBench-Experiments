# NetAgentBench experiment reports

Run logs, replays, analysis scripts and figures for the NetAgentBench manuscript:
8 models x 5 tasks x 10 repeats = 400 single-agent runs on live FRRouting topologies.

## Contents

| Path | What it is |
|---|---|
| `runs/<task_id>/<run_id>.json` | The 400 run logs, one file per run |
| `replays/<run_id>.json` | Replay of each run's command sequence on a fresh lab, three times |
| `analyses/` | All tables and figures, produced by `scripts/run_all_analyses.sh` |
| `analyses/summary/numbers.md` | The aggregate numbers quoted in `analysis.md` |
| `analysis.md` | Guide to the analyses: questions, figures, findings |
| `paper_figures/` | The figures used in the manuscript, with `PROVENANCE.md` and `case_study_runs.csv` |
| `scripts/` | Analysis scripts (offline; they read `runs/`, `replays/` and the repository's `tasks/multi_turn_v2/`) |

## Rebuilding the analyses

From the root of the NetAgentBench repository, with the Poetry environment installed:

```bash
./experiments_reports/scripts/run_all_analyses.sh
```

The script deletes and rebuilds `analyses/`, refreshes the data figures in
`paper_figures/`, and writes `analyses/summary/numbers.md`. It needs no lab and no model
API, only `runs/`, `replays/` and `tasks/multi_turn_v2/`. Each step's output is in `analyses/logs/`.

| Script | Output |
|---|---|
| `analyze_v2_sweep.py` | `analyses/sweep/`: terminal completeness, incomplete-run patterns, command effects, progress, time and turns |
| `analyze_process.py` | `analyses/process/`: cost, convergence lag, process fingerprint, anomalies (runs with commands) |
| `analyze_replay_determinism.py` | `analyses/replay/`: replay agreement per run |
| `rq2_resolution.py` | `analyses/rq2_resolution/`: score resolution and fulfilment orders |
| `rq2_views.py`, `model_property_matrix.py` | `analyses/rq2_views/`: property failures per model and task |
| `generate_trajectory_variants.py` | `analyses/trajectory_cases/`: per-command trajectories, first three repeats per model |
| `plot_bgp_route_comparisons.py`, `fig_incomplete_bgp_filtered.py` | `analyses/case_studies/`: fixed-run case studies |
| `release_numbers.py` | `analyses/summary/`: the numbers quoted in `analysis.md` |
| `organize_analyses.py` | Sorts each analysis folder into `tables/` and `figures/<family>/` |
| `report_style.py`, `snapshots.py`, `trajectory.py` | Shared helpers |

## How the runs were produced

- **Benchmark harness and tasks:** NetAgentBench, task definitions in `tasks/multi_turn_v2/`.
  Each run was started with
  `benchmark run-task <task> --provider openrouter --model <model> --agent-mode single --turn-limit 100 --time-limit 1800 --reveal-snapshots`.
  `--reveal-snapshots` records the property vector after every command in the log; the
  agent does not see it.
- **Agent:** single-agent ReAct loop served by the agent server reproduced in
  `agent_harness/` of the NetAgentBench repository. The agent receives the task goal and
  topology; the injected fault, reference solution and property checks are withheld.
- **Models:** served through OpenRouter with provider defaults.
- **Batches:** three repeats per cell on 2026-09-28 to 2026-09-30, seven more on
  2026-10-06 to 2026-10-08, same harness and agent code. Run ids contain the start time.
- **Runs with no command:** 23 runs issued no command and are kept as observed ($C = 0$);
  see `analysis.md`, section 2. One run (`openrouter_qwenqwen38flash_single_mt_20261006_224125_12e5a5fa`)
  lost its connection to the agent server mid-run (`termination_reason: dagent_timeout`)
  and has no token count.

## Run log format (`runs/`)

| Field | Content |
|---|---|
| `run_id`, `task_id`, `model_version`, `timestamp` | Identification |
| `property_results` | Final check of each intent property: observed output and `satisfied` |
| `scoring.completeness` | Terminal score $C$, the fraction of properties satisfied (the score used throughout) |
| `command_transcript` | Every command: `node`, `command`, `command_type` (read or config), `success` |
| `execution_log`, `actions` | Raw harness log and the agent's tool calls with results |
| `reasoning_trace` | The agent's reasoning steps |
| `metrics.property_trajectory` | Property vector after each command |
| `metrics.token_usage`, `metrics.termination_reason`, timing fields | Cost and termination |

`scoring` also holds robustness and syntactic-validity components and a weighted
`final_score`; the analyses use `completeness` only.

## Replay format (`replays/`)

Each file replays one run's command sequence three times on fresh labs, with a fixed
wait before scoring. `v2_*` fields score the tasks as defined in `tasks/multi_turn_v2/`;
`v1_*` fields score the earlier task definitions on the same final state, for comparison.
`replays[i].trajectory` holds the property vector after each replayed command. Replays of
the second batch also store each command's output and timing and the routers' container
logs. Runs with no command have a replay file marked `skipped`.
