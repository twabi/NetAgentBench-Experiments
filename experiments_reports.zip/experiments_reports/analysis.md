# Analysis guide: what the runs show and where to find it

This document explains the analyses under `analyses/`: the question each one answers,
where its figures and tables are, and what they show. Aggregate numbers quoted here come
from `analyses/summary/numbers.md`, which `scripts/release_numbers.py` computes from the
analysis tables; if one disagrees with `numbers.md`, `numbers.md` is correct. Details of
individual runs and replays (for example the replay exceptions in section 4) come from
the run and replay files themselves.

The figures used in the manuscript are in `paper_figures/`; see
`paper_figures/PROVENANCE.md`.

---

## 1. Why these analyses

A terminal score $C$ (the fraction of intent properties that hold at the end of a run)
says whether the final network state was correct. It does not say how the agent got
there, whether it understood what it changed, or whether the score depends on when we
stop looking. The analyses address four questions:

1. **Discrimination.** Does the benchmark separate model generations?
2. **Failure structure.** When a run fails, how does it fail?
3. **Process.** Do runs with the same score take the same route?
4. **Measurement validity.** Is the terminal score a faithful summary of the run, and is
   the lab itself deterministic?

---

## 2. Experimental setup

**Models.** Eight models served through OpenRouter, in two cohorts:

| Cohort | Models |
|---|---|
| Earlier-generation | GPT-5 Mini, Llama 3.3 70B, Qwen3 Coder 30B, Qwen3 Coder Next |
| Frontier | Qwen3.8 Flash, Gemini 3.1 Flash Lite, GPT-6 Luna, GLM 5.3 |

**Tasks.** Five tasks from `tasks/multi_turn_v2/` in the NetAgentBench repository:

- `ccna_rip_routing_basic` (basic, configuration)
- `troubleshoot_ospf_adjacency_issue` (intermediate, troubleshooting)
- `ccnp_multiarea_ospf_intermediate` (intermediate, configuration)
- `ccie_bgp_dual_homing_expert` (expert, configuration)
- `troubleshoot_bgp_route_filtering` (intermediate, troubleshooting)

The difficulty labels are the `research_context.complexity` field of each task.

**Runs.** 400 runs: 8 models x 5 tasks x 10 repeats; every model x task cell has 10 runs.
Each run is a single-agent ReAct session with a limit of 100 tool calls and 1800 s. Every
tool call counts against the limit: device commands, status queries, node listings, and
malformed calls alike. No run issued more than 98 device commands; the 17 runs that
reached the limit did so through other or malformed calls. The agent sees the task goal
and topology, not the property checks.

The runs were collected in two batches with the same harness: three repeats per cell
(2026-09-28 to 2026-09-30) and seven more (2026-10-06 to 2026-10-08). Run ids contain
the model name and the start time, so within a model sorting by run id gives date order.

**Snapshots.** The harness records the property vector after every command, reads
included. This is what the process analyses use.

**Runs with no command.** 23 of the 400 runs issued no command at all: 16 Qwen3 Coder
Next, 5 Qwen3 Coder 30B, and 2 GPT-6 Luna. Most Qwen3 Coder Next runs of this kind called
the command tool with empty arguments until the budget ran out; the GPT-6 Luna runs
submitted immediately. These runs are kept as observed and count as $C = 0$. They have
no trajectory, so the process analyses (`analyses/process/`) cover the other 377 runs.

### 2.1 Task intent properties

Each task is scored by a fixed list of intent properties. Each property is a predicate
over the live network state, checked by a read-only command on a named node.

**`ccna_rip_routing_basic` (5 properties).** Four routers R1 to R4 in a ring must reach
each other with RIPv2. R1's loopback 10.0.0.1/32 must reach R4's loopback 10.0.0.4/32
over a RIP-learned route, and authentication must be enabled on R1's two router links.

| Property | What it checks |
|---|---|
| `rip_enabled` | RIP process is running on R1 |
| `ripv2_enforced` | R1 sends and receives version 2 explicitly (FRR's default sends v2 but accepts v1) |
| `rip_authentication` | Authentication is configured on both of R1's router links (eth1, eth2) |
| `r4_loopback_via_rip` | R1 has a RIP-learned best route to 10.0.0.4/32 |
| `loopback_reachability` | Ping from R1's loopback to R4's loopback succeeds |

**`troubleshoot_ospf_adjacency_issue` (4 properties).** A four-router OSPF ring
(R1-R2-R3-R4-R1) should run entirely in Area 0. R3's link to R2 is in Area 1, so one
adjacency is down and traffic takes the long way around. The fix is to move R3's
10.0.23.0/30 into Area 0.

| Property | What it checks |
|---|---|
| `fault_corrected` | R3's link to R2 (eth1) is back in Area 0 |
| `r2_r3_adjacency_full` | The R2-R3 adjacency is Full |
| `r2_uses_restored_link` | R2 reaches R3's loopback over the repaired direct link (10.0.23.2 via eth2) |
| `topology_reconverged` | R1 load-shares to R3 via both R2 and R4 |

**`ccnp_multiarea_ospf_intermediate` (7 properties).** Five routers. Area 0 holds R1 and
the backbone links of R2 and R3. R2 is the ABR for Area 1 (R4), R3 the ABR for Area 2
(R5). Area 1 must be summarized as 10.1.0.0/16 at R2 and Area 2 as 10.2.0.0/16 at R3,
and the two non-backbone areas must reach each other.

| Property | What it checks |
|---|---|
| `backbone_adjacencies_full` | R1 has Full adjacencies with both ABRs (R2 and R3) |
| `area1_adjacency_full` | R4 has a Full adjacency with R2 |
| `area2_adjacency_full` | R5 has a Full adjacency with R3 |
| `interarea_routes_in_backbone` | R1 holds inter-area routes for both Area 1 and Area 2 prefixes |
| `area1_to_area2_reachability` | R4's loopback reaches R5's loopback |
| `area1_summarized` | R1 sees the summary 10.1.0.0/16 and not the Area 1 /30 |
| `area2_summarized` | R1 sees the summary 10.2.0.0/16 and not the Area 2 /30 |

**`ccie_bgp_dual_homing_expert` (6 properties).** EDGE1, EDGE2 and CORE are AS 65100.
EDGE1 peers with ISP1 (AS 65001), EDGE2 with ISP2 (AS 65002). The enterprise advertises
only prefixes inside 10.0.0.0/8; routes EDGE1 learns from ISP1 carry local preference
above 100; ISP2 receives an enterprise prefix with a prepended AS path; the EDGE1-ISP1
hold time is below 60 seconds.

| Property | What it checks |
|---|---|
| `ebgp_isp1_established` | EDGE1's session to ISP1 is Established |
| `ebgp_isp2_established` | EDGE2's session to ISP2 is Established |
| `outbound_filtering` | ISP1 learns at least one 10/8 prefix from EDGE1 and nothing else |
| `primary_path_preference` | EDGE1 assigns local preference above 100 to routes from ISP1 |
| `as_path_prepending` | ISP2 receives an enterprise prefix from EDGE2 with a repeated AS in the path |
| `fast_failover_timers` | The negotiated hold time on EDGE1's ISP1 session is below 60 seconds |

**`troubleshoot_bgp_route_filtering` (2 properties).** The edge router EDGE (AS 65000)
leaks its internal prefixes to the ISP (AS 65001). After the fix, EDGE advertises only
192.0.2.0/24 and the ISP learns only that prefix from EDGE. The injected fault is a
route-map `ALLOW-ALL` applied outbound instead of the defined `FILTER-OUT`.

| Property | What it checks |
|---|---|
| `filter_applied_outbound` | EDGE advertises 192.0.2.0/24 to the ISP and no other prefix |
| `isp_receives_authorized_only` | The ISP learns 192.0.2.0/24 from EDGE and no other prefix |

---

## 3. Run statistics

Full tables: `analyses/summary/numbers.md`. Per-run data: `analyses/sweep/tables/per_run.csv`
(all 400 runs) and `analyses/process/tables/per_run_process.csv` (377 runs with commands).

**Outcomes.** 286 runs are complete ($C = 1.0$), 60 partial, 54 zero.

| Cohort | Runs | Complete | Partial | Zero | Mean C |
|---|---|---|---|---|---|
| Earlier-generation | 200 | 107 | 43 | 50 | 0.66 |
| Frontier | 200 | 179 | 17 | 4 | 0.94 |

By model, mean $C$ ranges from 1.00 (GLM 5.3, all 50 runs complete) to 0.41 (Qwen3 Coder
30B, 26 zero runs). By task, BGP dual-homing is the hardest (mean $C$ 0.59, 33 of 80 runs
complete) and accounts for 31 of the 60 partial runs.

**Do repeated runs agree?** Within a model x task cell, the ten runs agree less than one
might expect: all ten land in the same outcome bucket in 19 of 40 cells, and all ten have
the same terminal $C$ in 17 of 40. The mean within-cell spread of $C$ is 0.444. Only GLM
5.3 scores the same in every one of its five cells. A single run is therefore a weak
estimate of a model's ability on a task; the spread is largest for the weakest models.

**Termination.** 339 runs submitted, 58 ended without a submission (`unknown`), 2 hit the
time limit, and 1 lost the connection to the agent server (`dagent_timeout`; that run has
no token count).

---

## 4. Is the lab deterministic? (`analyses/replay/`)

A replay runs a recorded command sequence again on a fresh lab, three times, with no model
involved. It tests the environment, not the model.

| Measure | Count |
|---|---|
| Runs replayed (at least one command) | 377 |
| All three replays completed and agree | 371 of 377 |
| First replay matches the live run's final state | 376 of 377 |

The six exceptions are listed in `numbers.md`. In four of them (all from the second
batch, whose replays record container logs), one replay diverged for the same reason: on
one router, FRR's daemon supervisor (watchfrr) restarted all routing daemons shortly after
boot (about 80 s after boot, after logging that startup did not complete in time, in three
of the four; about 62 s after boot without that message in the fourth). The restart discarded the
configuration the replay had already applied on that router, and that router carried the
properties that then failed. The fifth (a Qwen3.8 Flash RIP run from the first batch,
replays scoring 1.0, 1.0 and 0.2) predates the container logging; its per-command
snapshots show R1's RIP configuration disappearing mid-replay, which matches the same
restart. The sixth (a Llama 3.3 70B RIP run) had one replay refused at startup because the
router shell was not ready; its two completed replays agree. In the four logged cases the
divergence comes from the testbed's startup, not from the agent's commands or the
scoring; for the fifth this is inferred.

The restart itself is common. Of the 791 second-batch replays that record container logs,
188 show it on at least one router, and 184 of these replays still reproduced the live
run's final state. Whether a restart changes the outcome depends on when it happens
relative to the commands on that router; the replay files record both the command times
and the container logs, but this analysis does not align them.

---

## 5. Discrimination (`analyses/sweep/figures/completeness/`)

`fig2_completeness_earlier` and `fig2_completeness_frontier` show every run's terminal
$C$, one panel per cohort, one slice per run. The frontier cohort is close to saturated
(179 of 200 runs complete); the earlier-generation cohort supplies most of the failures
(50 of the 54 zero runs). The cohort gap is driven by three earlier-generation models
(Llama 3.3 70B, Qwen3 Coder Next and Qwen3 Coder 30B); GPT-5 Mini, also
earlier-generation, scores higher (mean $C$ 0.95) than two frontier models (0.89 each).
The benchmark separates strong from weak models while staying within reach of current
ones.

`analyses/sweep/figures/incomplete/` shows, for each task, which properties incomplete runs
hold. On BGP dual-homing, for example, the policy properties (filter, local preference, prepending)
are the ones most often missed (`analyses/rq2_views/figures/model_property_failure_bgp/`).

---

## 6. How failure looks

**`analyses/sweep/figures/path_events/`.** Each state-changing command (classified by its
content, not by the agent's label) is classified by what happens to the property vector
between it and the next state-changing command: regression (a true property became
false; this takes precedence), progress (a property became true for the first time in
the run), or no visible change. A high share of "no visible change" means commands that
do not move the state; a non-zero regression share means the agent undoes its own work.

**`analyses/trajectory_cases/` and `analyses/process/figures/trajectory_cases/`.**
Per-command trajectories, one line per run, for the first three repeats of each model.
Markers: `x` where a property was lost, a filled circle for a terminal $C = 1.0$, a hollow
circle below 1.0; line style marks repeat 1, 2 or 3. These show plateaus, divergence
between repeats, and regressions that a terminal score hides.

**`analyses/case_studies/`.** Single-run comparisons on BGP dual-homing: two partial runs
with the same score ($C = 0.33$) that satisfy different properties, and two complete runs
that satisfy the properties in a different order.

---

## 7. Do equal scores mean equal behaviour?

**Score resolution (`analyses/rq2_resolution/tables/`).** On four of the five tasks, each
score level corresponds to exactly one property vector. Only on BGP dual-homing do equal
scores hide different vectors (0.294 bits of vector uncertainty at a given score; 0.059
bits pooled over all tasks). The order in which properties become true carries more
information: the 286 complete runs follow 71 distinct fulfilment orders, 46 of them among
the 65 complete multi-area OSPF runs. Properties that become true only during the
post-submit convergence wait count as the last step of the order.

**Cost (`analyses/process/figures/cost_*`, table `process/tables/spread_equal_score.csv`).**
Among runs that reached $C = 1.0$ on the same task, cost varies widely. On RIP, the most
read-heavy complete run issued 35 times as many reads as the least; on BGP route filtering,
token use varies by a factor of 68.9.

**Convergence (`analyses/process/figures/convergence_lag/`).** Of the 286 complete runs,
101 were already at $C = 1.0$ right after their last state-changing command, 272 by the
time the agent submitted, and 14 only after the post-submit convergence wait. Most
complete runs reach the goal during the agent's trailing reads, not at the last write.

---

## 8. What distinguishes models (`analyses/process/figures/process_fingerprint/`)

The fingerprint table (`process/tables/fingerprint.csv`) covers successful runs. The ratio
columns (writes, reads, wall time, tokens) are geometric means of each run's value over
the median for its task across all models' successful runs, so 1.0 is typical (runs with
a value of 0 are left out of the mean). The remaining columns are
medians (reads before the first change, reads after the last change, configuration lines
per command) or counts (regressions, disruptive actions, hidden writes, phantom writes,
failed commands).

- Llama 3.3 70B writes the most (4.16x) and reads the least (0.51x): it acts without
  inspecting.
- Qwen3 Coder Next and Qwen3 Coder 30B use the most tokens (2.90x and 2.49x); Qwen3 Coder
  Next also reads the most (2.36x).
- Gemini 3.1 Flash Lite is the fastest (0.42x wall time) and among the cheapest in tokens
  (0.71x), but in its successful runs labels 161 read-only commands as state-changing
  (phantom writes), far more than any other model.
- GLM 5.3 issues the fewest state-changing commands (0.80x) with the most configuration
  lines per command (4.0).

**Process anomalies** (runs with at least one, of 377): failed command 203, phantom write
68, regression 56, disruptive operation 46, unconverged at submit 18, hidden write 15.

`analyses/sweep/figures/time_turns/` shows, per run and task, the number of state-changing
commands and the wall time in two panels, marking runs where the number of commands the
agent labelled config differs from the number that changed state.

---

## 9. Limitations

1. **Snapshot timing.** Per-command snapshots are taken shortly after each command, so a
   slowly converging property can look false in a snapshot and true at the final check.
   The final check is taken after a fixed post-submit wait of 45 to 120 s, set per task.
2. **Testbed startup.** FRR's daemon supervisor often restarts all daemons on a router
   shortly after boot (188 of 791 logged replays, section 4). In replay this changed the outcome of one
   replay in 4 of 377 runs, and very likely in a fifth. Live runs use the same startup path and could be affected in the same way.
3. **Cohort labels are ours.** "Earlier-generation" and "frontier" are descriptive
   groupings.

---

## 10. Figure index

| Folder | Figures | Question |
|---|---|---|
| `sweep/figures/completeness/` | `fig2_completeness_<cohort>` | Does the benchmark discriminate? |
| `sweep/figures/incomplete/` | `fig2_incomplete_<task>` | Which properties do incomplete runs hold? |
| `sweep/figures/path_events/` | `fig_path_events_<task>_<cohort>` | What does each command do to the state? |
| `sweep/figures/progress/` | `fig3_progress_<task>_<cohort>` | How quickly does completeness accumulate? |
| `sweep/figures/time_turns/` | `fig_time_turns_<cohort>` | How do effort and latency relate? |
| `trajectory_cases/figures/` | `figure_trajectory_cases_<cohort>_<axis>_<n>` | Per-command trajectories (first three repeats) |
| `process/figures/trajectory_cases/` | `fig_trajectory_cases_<cohort>_<n>` | Same, from the process analysis |
| `process/figures/cost_*/` | `fig_cost_<metric>_<cohort>` | What does a correct answer cost? |
| `process/figures/convergence_lag/` | `fig_convergence_lag` | When do properties become true? |
| `process/figures/process_fingerprint/` | `fig_process_fingerprint` | Do models behave differently? |
| `rq2_views/figures/` | `model_property_failure*`, `model_task_mean`, `property_failure` | Which properties each model fails |
| `case_studies/figures/` | `fig_trajectory_compare_bgp_*`, `fig2_incomplete_*` | Single-run case studies |
