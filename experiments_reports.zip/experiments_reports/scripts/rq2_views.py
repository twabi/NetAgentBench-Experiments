"""Two views for RQ2: model x task mean completeness, and per-task property failure rates.

Outputs (console + CSV + PNG/PDF) under experiments_reports/analyses/rq2_views/:
  model_task_mean.csv / .png   mean terminal completeness per model per task
  property_failure.csv / .png  share of runs in which each property is NOT satisfied

Read-only: does not touch the manuscript.
"""

from __future__ import annotations

import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
sys.path.insert(0, str(HERE))

from analyze_v2_sweep import (  # noqa: E402
    MODEL_LABELS,
    MODEL_ORDER,
    PROPERTY_LABELS,
    TASK_LABELS,
    TASK_ORDER,
    model_slug,
)

RUNS_DIR = REPO / "experiments_reports" / "runs"
OUT_DIR = REPO / "experiments_reports" / "analyses" / "rq2_views"
INK, MUTED = "#1f1f1e", "#6b6b68"


def load() -> list[dict]:
    rows = []
    for task_id in TASK_ORDER:
        for path in sorted((RUNS_DIR / task_id).glob("*.json")):
            data = json.loads(path.read_text())
            # Empty sessions (no commands) count: their terminal vector is all-unsatisfied.
            vector = {
                str(item["property_id"]): bool(item.get("satisfied"))
                for item in data.get("property_results") or []
                if item.get("property_id")
            }
            rows.append({
                "task_id": task_id,
                "model": model_slug(str(data.get("model_version") or "")),
                "completeness": float((data.get("scoring") or {}).get("completeness") or 0.0),
                "vector": vector,
            })
    return rows


def model_task_mean(rows: list[dict]) -> tuple[list[str], list[str], np.ndarray]:
    models = [m for m in MODEL_ORDER if any(r["model"] == m for r in rows)]
    grid = np.full((len(models), len(TASK_ORDER)), np.nan)
    for i, m in enumerate(models):
        for j, t in enumerate(TASK_ORDER):
            vals = [r["completeness"] for r in rows if r["model"] == m and r["task_id"] == t]
            if vals:
                grid[i, j] = float(np.mean(vals))
    return models, TASK_ORDER, grid


def property_failure(rows: list[dict]) -> dict[str, list[tuple[str, float, int]]]:
    """Per task: (property_id, failure share, n runs) in task property order."""
    out: dict[str, list[tuple[str, float, int]]] = {}
    for task_id in TASK_ORDER:
        task_rows = [r for r in rows if r["task_id"] == task_id]
        keys = list(task_rows[0]["vector"].keys()) if task_rows else []
        entries = []
        for key in keys:
            n = sum(1 for r in task_rows if key in r["vector"])
            failed = sum(1 for r in task_rows if not r["vector"].get(key, False))
            entries.append((key, failed / n if n else 0.0, n))
        out[task_id] = entries
    return out


def draw_model_task(models, tasks, grid, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7.2, 0.5 * len(models) + 1.6))
    cmap = plt.get_cmap("Blues")
    for i in range(len(models)):
        for j in range(len(tasks)):
            v = grid[i, j]
            ax.add_patch(plt.Rectangle((j + 0.03, i + 0.06), 0.94, 0.88,
                                       color=cmap(0.12 + 0.78 * v), linewidth=0))
            ax.text(j + 0.5, i + 0.5, f"{v:.2f}", ha="center", va="center", fontsize=7,
                    color="white" if v > 0.6 else INK)
    ax.set_xlim(0, len(tasks))
    ax.set_ylim(len(models), 0)
    ax.set_xticks([j + 0.5 for j in range(len(tasks))])
    ax.set_xticklabels([TASK_LABELS[t] for t in tasks], fontsize=7, color=INK,
                       rotation=20, ha="right", rotation_mode="anchor")
    ax.set_yticks([i + 0.5 for i in range(len(models))])
    ax.set_yticklabels([MODEL_LABELS.get(m, m) for m in models], fontsize=7, color=INK)
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.set_title("Mean terminal completeness per model per task (all runs per cell)",
                 fontsize=8.5, color=INK, loc="left")
    fig.tight_layout()
    fig.savefig(path.with_suffix(".png"), dpi=220, bbox_inches="tight")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def draw_property_failure(failure, path: Path) -> None:
    n_tasks = len(TASK_ORDER)
    fig, axes = plt.subplots(n_tasks, 1, figsize=(7.2, 1.5 * n_tasks + 0.6))
    cmap = plt.get_cmap("OrRd")
    for ax, task_id in zip(axes, TASK_ORDER):
        entries = failure[task_id]
        for j, (key, share, n) in enumerate(entries):
            ax.add_patch(plt.Rectangle((j + 0.03, 0.06), 0.94, 0.88,
                                       color=cmap(0.05 + 0.9 * share), linewidth=0))
            ax.text(j + 0.5, 0.5, f"{share * 100:.0f}%", ha="center", va="center", fontsize=7,
                    color="white" if share > 0.55 else INK)
        ax.set_xlim(0, len(entries))
        ax.set_ylim(0, 1)
        ax.set_xticks([j + 0.5 for j in range(len(entries))])
        ax.set_xticklabels([PROPERTY_LABELS.get(k, k) for k, _, _ in entries],
                           fontsize=6.5, color=INK, rotation=18, ha="right", rotation_mode="anchor")
        ax.set_yticks([])
        ax.tick_params(length=0)
        for spine in ax.spines.values():
            spine.set_visible(False)
        ax.set_title(f"{TASK_LABELS[task_id]}  (n = {entries[0][2] if entries else 0} runs)",
                     fontsize=8, color=INK, loc="left")
    fig.suptitle("Share of runs in which each property is NOT satisfied (all models, all repeats)",
                 fontsize=9, color=INK, x=0.02, ha="left")
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(path.with_suffix(".png"), dpi=220, bbox_inches="tight")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = load()
    print(f"loaded {len(rows)} runs\n")

    models, tasks, grid = model_task_mean(rows)
    print("=== Mean terminal completeness per model per task ===")
    header = "model".ljust(24) + "".join(TASK_LABELS[t][:14].rjust(16) for t in tasks)
    print(header)
    for i, m in enumerate(models):
        line = MODEL_LABELS.get(m, m).ljust(24)
        line += "".join(f"{grid[i, j]:16.2f}" for j in range(len(tasks)))
        print(line)
    with (OUT_DIR / "model_task_mean.csv").open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["model"] + [TASK_LABELS[t] for t in tasks])
        for i, m in enumerate(models):
            w.writerow([MODEL_LABELS.get(m, m)] + [f"{grid[i, j]:.3f}" for j in range(len(tasks))])
    draw_model_task(models, tasks, grid, OUT_DIR / "model_task_mean")

    failure = property_failure(rows)
    print("\n=== Share of runs where each property is NOT satisfied ===")
    for task_id in TASK_ORDER:
        print(f"\n{TASK_LABELS[task_id]}")
        for key, share, n in failure[task_id]:
            print(f"  {PROPERTY_LABELS.get(key, key):20s} {share * 100:5.1f}%  (n={n})")
    with (OUT_DIR / "property_failure.csv").open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["task", "property", "failure_share", "n_runs"])
        for task_id in TASK_ORDER:
            for key, share, n in failure[task_id]:
                w.writerow([TASK_LABELS[task_id], PROPERTY_LABELS.get(key, key), f"{share:.3f}", n])
    draw_property_failure(failure, OUT_DIR / "property_failure")

    print(f"\nwrote CSVs and figures to {OUT_DIR}")


if __name__ == "__main__":
    main()
