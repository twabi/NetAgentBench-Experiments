"""RQ2 resolution: how much a property vector says beyond the scalar completeness score.

For each task (and pooled), counts distinct terminal scores vs distinct property
vectors, how many distinct vectors share each score level, and the conditional
entropy H(vector | score), i.e. the information a scalar score discards. Also
counts distinct fulfillment orders among complete runs (the order in which
properties first became true on the per-turn trajectory).

Outputs (console + CSV) under experiments_reports/analyses/rq2_resolution/:
  summary.csv      one row per task plus a pooled row
  score_levels.csv one row per (task, score level) with >= 1 run

Usage: python rq2_resolution.py [--runs-dir DIR ...] [--out-dir DIR]
Several --runs-dir values are pooled (e.g. the September and extra-repeat cohorts).
Read-only: does not touch the manuscript.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
sys.path.insert(0, str(HERE))

from analyze_v2_sweep import TASK_LABELS, TASK_ORDER  # noqa: E402

RUNS_DIR = REPO / "experiments_reports" / "runs"
OUT_DIR = REPO / "experiments_reports" / "analyses" / "rq2_resolution"


def load_runs(runs_dirs: list[Path]) -> list[dict]:
    runs = []
    for runs_dir in runs_dirs:
        for path in sorted(runs_dir.glob("*/*.json")):
            data = json.loads(path.read_text())
            if not isinstance(data.get("scoring"), dict):
                continue
            props = data["property_results"]
            ids = tuple(p["property_id"] for p in props)
            vector = tuple(bool(p["satisfied"]) for p in props)
            runs.append(
                {
                    "task": data["task_id"],
                    "model": data["model_version"].split(":", 1)[-1],
                    "ids": ids,
                    "vector": vector,
                    "score": round(sum(vector) / len(vector), 4),
                    "order": fulfillment_order(data, ids),
                }
            )
    return runs


def fulfillment_order(data: dict, ids: tuple[str, ...]) -> tuple:
    """Properties grouped by the turn they first became true; ties form one group."""
    first: dict[str, int] = {}
    for snap in (data.get("metrics") or {}).get("property_trajectory") or []:
        for pid, ok in snap.get("properties", {}).items():
            if ok and pid not in first:
                first[pid] = snap["turn"]
    by_turn: dict[int, list[str]] = defaultdict(list)
    for pid in ids:
        if pid in first:
            by_turn[first[pid]].append(pid)
    order = tuple(tuple(sorted(by_turn[t])) for t in sorted(by_turn))
    # Properties never true in a snapshot but true at the final check became true
    # during the post-submit convergence wait: they form the last group.
    final = {p["property_id"] for p in data.get("property_results") or [] if p.get("satisfied")}
    late = tuple(sorted(pid for pid in ids if pid in final and pid not in first))
    return order + ((late,) if late else ())


def entropy(counts: Counter) -> float:
    n = sum(counts.values())
    return -sum(c / n * math.log2(c / n) for c in counts.values() if c)


def summarize(label: str, runs: list[dict]) -> tuple[dict, list[dict]]:
    # Pooled rows key vectors by task too, since property sets differ per task.
    vec = Counter((r["task"], r["vector"]) for r in runs)
    score = Counter((r["task"], r["score"]) for r in runs)
    joint_h = entropy(vec)  # vector determines score, so H(V, S) = H(V)
    levels = []
    by_score: dict[tuple, list[dict]] = defaultdict(list)
    for r in runs:
        by_score[(r["task"], r["score"])].append(r)
    for (task, s), group in sorted(by_score.items()):
        levels.append(
            {
                "task": task,
                "score": s,
                "runs": len(group),
                "distinct_vectors": len({r["vector"] for r in group}),
                "models": len({r["model"] for r in group}),
            }
        )
    partial = [r for r in runs if 0 < r["score"] < 1]
    complete = [r for r in runs if r["score"] == 1]
    row = {
        "task": label,
        "runs": len(runs),
        "distinct_scores": len(score),
        "distinct_vectors": len(vec),
        "partial_runs": len(partial),
        "distinct_partial_vectors": len({(r["task"], r["vector"]) for r in partial}),
        "shared_score_levels": sum(1 for lv in levels if lv["distinct_vectors"] > 1),
        "H_vector_bits": round(joint_h, 3),
        "H_score_bits": round(entropy(score), 3),
        "H_vector_given_score_bits": round(joint_h - entropy(score), 3),
        "complete_runs": len(complete),
        "distinct_complete_orders": len({(r["task"], r["order"]) for r in complete}),
    }
    return row, levels


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs-dir", type=Path, action="append")
    ap.add_argument("--out-dir", type=Path, default=OUT_DIR)
    args = ap.parse_args()
    runs = load_runs(args.runs_dir or [RUNS_DIR])

    rows, all_levels = [], []
    for task in TASK_ORDER:
        task_runs = [r for r in runs if r["task"] == task]
        if not task_runs:
            continue
        row, levels = summarize(TASK_LABELS.get(task, task), task_runs)
        rows.append(row)
        all_levels.extend(levels)
    rows.append(summarize("All tasks", runs)[0])

    args.out_dir.mkdir(parents=True, exist_ok=True)
    for name, data in (("summary.csv", rows), ("score_levels.csv", all_levels)):
        with open(args.out_dir / name, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(data[0]))
            w.writeheader()
            w.writerows(data)

    cols = list(rows[0])
    print("\t".join(cols))
    for row in rows:
        print("\t".join(str(row[c]) for c in cols))
    print("\nScore levels shared by more than one vector:")
    for lv in all_levels:
        if lv["distinct_vectors"] > 1:
            print(f"  {lv['task']}  C={lv['score']:.2f}  runs={lv['runs']}  vectors={lv['distinct_vectors']}  models={lv['models']}")
    print(f"\nWrote {args.out_dir}")


if __name__ == "__main__":
    main()
