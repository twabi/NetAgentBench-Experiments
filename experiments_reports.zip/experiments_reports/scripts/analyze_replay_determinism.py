#!/usr/bin/env python
"""Replay-determinism statistics over the combined experiments_reports folder.

Reads every per-run replay JSON in experiments_reports/replays/ and computes,
in plain language:

  1. Coverage: how many of the runs in experiments_reports/runs/ have a replay,
     and why any are missing.
  2. Stability: when the same commands are replayed 3 times on fresh labs, do
     all 3 replays produce the same final property vector?
  3. Fidelity: does the replayed final state match what the original live run
     scored?
  4. Breakdowns by task, by model, and by cohort (earlier/frontier).

The old summary_legacy.json / summary_taxed.json are ignored: they predate the
rerun merge and count runs that no longer exist. This script reads the
per-run replay files directly, so it is always current.

Usage (from the benchmark repo root):
    poetry run python experiments_reports/scripts/analyze_replay_determinism.py
    poetry run python experiments_reports/scripts/analyze_replay_determinism.py \
        --runs-dir experiments_reports/runs \
        --replays-dir experiments_reports/replays \
        --out-dir experiments_reports/analyses/replay

Outputs: replay_determinism.csv (one row per replayed run) and a printed
summary. No figures; the numbers are the point.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from report_style import MODEL_FAMILIES, FAMILY_LABELS, MODEL_LABEL  # noqa: E402

EARLIER = set(MODEL_FAMILIES["earlier"])
FRONTIER = set(MODEL_FAMILIES["frontier"])


def model_slug(raw: str) -> str:
    """'openrouter:qwen/qwen3-coder-next' -> 'qwen/qwen3-coder-next'."""
    return raw.split(":", 1)[-1] if ":" in raw else raw


def family_of(model: str) -> str:
    if model in EARLIER:
        return "earlier"
    if model in FRONTIER:
        return "frontier"
    return "unknown"


def load_runs(runs_dir: Path) -> dict[str, dict]:
    """run_id -> run record, for runs with a non-empty command transcript."""
    runs = {}
    for path in sorted(runs_dir.glob("*/*.json")):
        d = json.loads(path.read_text())
        runs[d["run_id"]] = {
            "run_id": d["run_id"],
            "task_id": d["task_id"],
            "model": model_slug(str(d.get("model_version") or "")),
            "n_commands": len(d.get("command_transcript") or []),
            "terminal_c": float((d.get("scoring") or {}).get("completeness") or 0.0),
            "vector": {p["property_id"]: bool(p["satisfied"])
                       for p in d.get("property_results") or [] if p.get("property_id")},
        }
    return runs


def load_replays(replays_dir: Path) -> dict[str, dict]:
    """run_id -> replay record. Skips the stale summary files."""
    replays = {}
    for path in sorted(replays_dir.glob("*.json")):
        if path.name.startswith("summary_") or path.name == "summary.json":
            continue
        d = json.loads(path.read_text())
        replays[d["run_id"]] = d
    return replays


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--runs-dir", type=Path, default=Path("experiments_reports/runs"))
    ap.add_argument("--replays-dir", type=Path, default=Path("experiments_reports/replays"))
    ap.add_argument("--out-dir", type=Path, default=Path("experiments_reports/analyses/replay"))
    args = ap.parse_args()

    runs = load_runs(args.runs_dir)
    replays = load_replays(args.replays_dir)
    args.out_dir.mkdir(parents=True, exist_ok=True)

    # ---------------------------------------------------------------- coverage
    matched = [rid for rid in replays if rid in runs]
    stale = [rid for rid in replays if rid not in runs]          # replay of a run that no longer exists
    missing = [rid for rid in runs if rid not in replays]        # run with no replay yet
    skipped_replays = [rid for rid in matched if replays[rid].get("skipped")]
    scored = [rid for rid in matched if not replays[rid].get("skipped")]

    print("=" * 72)
    print("REPLAY DETERMINISM - combined folder")
    print("=" * 72)
    print(f"runs in {args.runs_dir}:            {len(runs)}")
    print(f"replay files in {args.replays_dir}: {len(replays)}")
    print(f"  matched to a current run:         {len(matched)}")
    print(f"  scored (commands were replayed):  {len(scored)}")
    print(f"  skipped inside the replay file:   {len(skipped_replays)}")
    for rid in skipped_replays:
        print(f"    - {rid}: {replays[rid].get('skipped')}")
    print(f"  stale (run no longer exists):     {len(stale)}")
    for rid in stale:
        print(f"    - {rid}")
    print(f"  current runs with NO replay yet:  {len(missing)}")
    for rid in missing:
        r = runs[rid]
        print(f"    - {rid}  ({r['task_id']}, {r['model']})")
    print()

    # ------------------------------------------------------------------ stats
    rows = []
    for rid in scored:
        rp = replays[rid]
        run = runs[rid]
        n_ok = rp.get("n_replays_ok") or 0
        v2cs = rp.get("v2_completeness") or []
        stable = bool(rp.get("stable_v2_vector"))
        matches = bool(rp.get("matches_original_v2"))
        # does the replayed state match the live run's terminal state?
        live_match = (rp.get("original_v2_vector") == rp.get("v2_vector"))
        rows.append({
            "run_id": rid,
            "task_id": rp["task_id"],
            "model": run["model"],
            "family": family_of(run["model"]),
            "n_commands": rp.get("n_commands"),
            "n_replays_ok": n_ok,
            "wait_s": rp.get("wait_s"),
            "stable_v2_vector": stable,
            "stable_v1_vector": bool(rp.get("stable_v1_vector")),
            "matches_original_v2": matches,
            "matches_live_run_vector": live_match,
            "original_v2_completeness": round(sum(rp["original_v2_vector"].values())
                                              / max(len(rp["original_v2_vector"]), 1), 4),
            "replay_v2_completeness": round(sum(v2cs) / len(v2cs), 4) if v2cs else None,
            "replay_v2_completeness_spread": round(max(v2cs) - min(v2cs), 4) if v2cs else None,
            "live_terminal_c": run["terminal_c"],
        })

    def block(title: str, groups: dict[str, list[dict]]) -> None:
        print(title)
        print(f"  {'group':44s} {'n':>4s} {'stable':>7s} {'match':>6s} {'live-match':>11s}")
        for name, g in sorted(groups.items()):
            n = len(g)
            s = sum(r["stable_v2_vector"] for r in g)
            m = sum(r["matches_original_v2"] for r in g)
            lm = sum(r["matches_live_run_vector"] for r in g)
            print(f"  {name:44s} {n:4d} {s:4d}/{n:<3d} {m:3d}/{n:<3d} {lm:4d}/{n:<3d}")
        print()

    by_task = defaultdict(list)
    by_model = defaultdict(list)
    by_family = defaultdict(list)
    for r in rows:
        by_task[r["task_id"]].append(r)
        by_model[r["model"]].append(r)
        by_family[r["family"]].append(r)

    n = len(rows)
    print("HEADLINE")
    print(f"  replayed runs analysed:                {n}")
    print(f"  all replays agree with each other:     "
          f"{sum(r['stable_v2_vector'] for r in rows)}/{n}")
    print(f"  replay matches the original scoring:   "
          f"{sum(r['matches_original_v2'] for r in rows)}/{n}")
    print(f"  replay matches the live run's state:   "
          f"{sum(r['matches_live_run_vector'] for r in rows)}/{n}")
    print()
    block("BY TASK (task_id)", by_task)
    block("BY MODEL", {MODEL_LABEL.get(m, m): g for m, g in by_model.items()})
    block("BY COHORT", {FAMILY_LABELS.get(f, f): g for f, g in by_family.items()})

    unstable = [r for r in rows if not r["stable_v2_vector"]]
    mismatch = [r for r in rows if not r["matches_original_v2"]]
    if unstable:
        print("UNSTABLE RUNS (the 3 replays did not all agree)")
        for r in unstable:
            print(f"  - {r['run_id']}  ({r['task_id']}, {r['model']}, "
                  f"spread={r['replay_v2_completeness_spread']})")
        print()
    if mismatch:
        print("FIDELITY MISMATCHES (replay state != original scoring)")
        for r in mismatch:
            print(f"  - {r['run_id']}  ({r['task_id']}, {r['model']})")
        print()
    if not unstable and not mismatch:
        print("No instability and no fidelity mismatch: every scored replay "
              "reproduced the original final state exactly, three times each.")
        print()

    # ------------------------------------------------------------------ csv
    out_csv = args.out_dir / "replay_determinism.csv"
    if rows:
        with out_csv.open("w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print(f"wrote {out_csv} ({len(rows)} rows)")
    else:
        print("no scored replays found; nothing written")


if __name__ == "__main__":
    main()