#!/usr/bin/env bash
# Rebuild every analysis under experiments_reports/analyses/ from runs/ and replays/.
#
# Offline: reads runs/, replays/ and the task definitions in tasks/multi_turn_v2/ (no lab, no model API).
# Run from the repository root:
#   ./experiments_reports/scripts/run_all_analyses.sh
#
# Output layout (after organize_analyses.py):
#   analyses/<analysis>/tables/          csv / json
#   analyses/<analysis>/figures/<family>/ png + pdf
#   analyses/logs/                        stdout of each step
#   analyses/summary/                     numbers quoted in analysis.md
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "${ROOT}"
X=experiments_reports
A="${X}/analyses"

rm -rf "${A}"
mkdir -p "${A}"

step() {
  local name="$1"; shift
  echo "== ${name}"
  "$@" > "${A}/${name}.log" 2>&1
}

step sweep poetry run python "${X}/scripts/analyze_v2_sweep.py" \
  --runs-dir "${X}/runs" --out-dir "${A}/sweep" --snapshot-mode all
step process poetry run python "${X}/scripts/analyze_process.py" \
  --runs-dir "${X}/runs" --out-dir "${A}/process" --snapshot-mode all
step replay poetry run python "${X}/scripts/analyze_replay_determinism.py" \
  --runs-dir "${X}/runs" --replays-dir "${X}/replays" --out-dir "${A}/replay"
step rq2_resolution poetry run python "${X}/scripts/rq2_resolution.py" \
  --runs-dir "${X}/runs" --out-dir "${A}/rq2_resolution"
step rq2_views poetry run python "${X}/scripts/rq2_views.py"
step model_property_matrix poetry run python "${X}/scripts/model_property_matrix.py"
step model_property_matrix_bgp poetry run python "${X}/scripts/model_property_matrix.py" \
  --tasks ccie_bgp_dual_homing_expert --out model_property_failure_bgp
step trajectory_cases poetry run python "${X}/scripts/generate_trajectory_variants.py"
step case_studies poetry run python "${X}/scripts/plot_bgp_route_comparisons.py"
step case_incomplete_bgp poetry run python "${X}/scripts/fig_incomplete_bgp_filtered.py"
step summary poetry run python "${X}/scripts/release_numbers.py"
poetry run python "${X}/scripts/organize_analyses.py"
# Logs print absolute output paths; keep them repository-relative.
sed -i "s#${ROOT}/##g" "${A}"/logs/*.log

# Figures used in the manuscript (diagrams under paper_figures/diagrams/ are static).
P="${X}/paper_figures"
mkdir -p "${P}"
for f in \
  case_studies/figures/incomplete/fig2_incomplete_ccie_bgp_dual_homing_expert \
  rq2_views/figures/model_property_failure_bgp/model_property_failure_bgp \
  trajectory_cases/figures/trajectory_cases_commands/figure_trajectory_cases_earlier_commands_2 \
  trajectory_cases/figures/trajectory_cases_commands/figure_trajectory_cases_frontier_commands_2 \
  case_studies/figures/trajectory_compare_bgp_partial_tokens/fig_trajectory_compare_bgp_partial_tokens \
  case_studies/figures/trajectory_compare_bgp_complete_tokens/fig_trajectory_compare_bgp_complete_tokens; do
  cp "${A}/${f}.pdf" "${A}/${f}.png" "${P}/"
done
echo "== done"
