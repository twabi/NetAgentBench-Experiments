"""Shared plotting style for the combined legacy+taxed analyses.

8 models (4 legacy + 4 taxed), Okabe-Ito colour-blind-safe palette with a
redundant marker cue per model. All figures in experiments_reports use this.
"""
from __future__ import annotations

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

INK, MUTED, GRID = "#1f1f1e", "#6b6b68", "#e4e4e1"

# (model_version substring, display label, colour, marker)
# Legacy cohort (older models) first, taxed cohort (frontier) second.
MODELS = [
    ("openai/gpt-5-mini",                    "GPT-5 Mini",            "#E69F00", "o"),
    ("meta-llama/llama-3.3-70b-instruct",    "Llama 3.3 70B",         "#56B4E9", "s"),
    ("qwen/qwen3-coder-30b-a3b-instruct",    "Qwen3 Coder 30B",       "#009E73", "^"),
    ("qwen/qwen3-coder-next",                "Qwen3 Coder Next",      "#F0E442", "D"),
    ("qwen/qwen3.8-flash",                   "Qwen3.8 Flash",         "#0072B2", "v"),
    ("google/gemini-3.1-flash-lite",         "Gemini 3.1 Flash Lite", "#CC79A7", "P"),
    ("openai/gpt-6-luna",                    "GPT-6 Luna",            "#D55E00", "X"),
    ("z-ai/glm-5.3",                         "GLM 5.3",               "#000000", "*"),
]
MODEL_FAMILIES = {
    "earlier": [
        "openai/gpt-5-mini",
        "meta-llama/llama-3.3-70b-instruct",
        "qwen/qwen3-coder-30b-a3b-instruct",
        "qwen/qwen3-coder-next",
    ],
    "frontier": [
        "qwen/qwen3.8-flash",
        "google/gemini-3.1-flash-lite",
        "openai/gpt-6-luna",
        "z-ai/glm-5.3",
    ],
}
# Reader-facing labels for the two model generations (internal names: legacy / taxed).
FAMILY_LABELS = {"earlier": "Earlier-generation models", "frontier": "Frontier models"}
MODEL_LABEL = {m: lab for m, lab, _, _ in MODELS}
MODEL_COLOR = {m: c for m, _, c, _ in MODELS}
MODEL_MARKER = {m: mk for m, _, _, mk in MODELS}

RUN_STYLES = ["-", "--", ":"]  # run index within a model


def style(ax):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(MUTED)
        ax.spines[s].set_linewidth(0.6)
    ax.tick_params(colors=MUTED, labelsize=7, width=0.6, length=2.5)
    ax.grid(axis="x", color=GRID, linewidth=0.6)
    ax.set_axisbelow(True)


def save(fig, out_dir, name):
    out_dir = str(out_dir)
    fig.savefig(f"{out_dir}/{name}.pdf", bbox_inches="tight")
    fig.savefig(f"{out_dir}/{name}.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def model_legend(fig, hollow_label=None, **kwargs):
    """One shared legend for the 8 models, frameless, placed at the top."""
    handles = [
        Line2D([], [], color=c, marker=mk, linestyle="-", markersize=5,
               markerfacecolor=c, label=lab, linewidth=1.4)
        for _, lab, c, mk in MODELS
    ]
    if hollow_label:
        handles.append(Line2D([], [], color=MUTED, marker="o", linestyle="",
                              markersize=5.5, markerfacecolor="white",
                              markeredgewidth=1.0, label=hollow_label))
    defaults = dict(loc="upper center", bbox_to_anchor=(0.5, 1.14),
                    ncol=4, frameon=False, fontsize=7, handlelength=1.6,
                    columnspacing=1.2)
    defaults.update(kwargs)
    fig.legend(handles=handles, **defaults)