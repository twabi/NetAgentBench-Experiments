"""Tidy experiments_reports/analyses after the analysis scripts have run.

The analysis scripts write everything flat into their output folder. This script
moves, inside each analysis folder:
  * tables (csv, json) into  <analysis>/tables/
  * figures (png, pdf) into  <analysis>/figures/<family>/
and the run logs (analyses/*.log) into analyses/logs/.

A figure's family is its file stem with the figure-number prefix (fig_, fig2_,
figure_, ...), the task id, the cohort suffix (_earlier/_frontier) and a trailing
variant number removed, e.g.
  fig3_progress_ccna_rip_routing_basic_earlier.pdf  ->  figures/progress/
  fig_cost_tokens_frontier.png                      ->  figures/cost_tokens/

Idempotent: files already inside tables/ or figures/ are left alone. Rerun it after
any analysis script, because the scripts write flat again.

Usage:
    poetry run python experiments_reports/scripts/organize_analyses.py
"""

from __future__ import annotations

import re
import shutil
from pathlib import Path

ANALYSES = Path(__file__).resolve().parents[1] / "analyses"
TASK_IDS = (
    "ccna_rip_routing_basic",
    "troubleshoot_ospf_adjacency_issue",
    "ccnp_multiarea_ospf_intermediate",
    "ccie_bgp_dual_homing_expert",
    "troubleshoot_bgp_route_filtering",
)
TABLE_EXT = {".csv", ".json"}
FIGURE_EXT = {".png", ".pdf"}


def family(stem: str) -> str:
    s = re.sub(r"^(fig(ure)?\d*_)", "", stem)
    for task in TASK_IDS:
        s = s.replace(f"_{task}", "")
    s = re.sub(r"_(earlier|frontier)(?=_|$)", "", s)
    s = re.sub(r"_\d+$", "", s)
    return s or "misc"


def main() -> None:
    moved = 0
    logs = ANALYSES / "logs"
    for log in ANALYSES.glob("*.log"):
        logs.mkdir(exist_ok=True)
        shutil.move(str(log), logs / log.name)
        moved += 1
    for folder in sorted(p for p in ANALYSES.iterdir() if p.is_dir() and p.name != "logs"):
        for path in sorted(p for p in folder.iterdir() if p.is_file()):
            if path.suffix in TABLE_EXT:
                dest = folder / "tables"
            elif path.suffix in FIGURE_EXT:
                dest = folder / "figures" / family(path.stem)
            else:
                continue
            dest.mkdir(parents=True, exist_ok=True)
            shutil.move(str(path), dest / path.name)
            moved += 1
    print(f"moved {moved} files under {ANALYSES}")


if __name__ == "__main__":
    main()
