"""Generate trajectory figures for commands, turns, and tokens across generations and task pairs.

Outputs are written to experiments_reports/analyses/trajectory_cases/.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from report_style import MODEL_FAMILIES, style
from analyze_process import (
    MODELS,
    TASK_LABEL,
    M_LABEL,
    INK,
    MUTED,
    GRID,
    classify,
    model_of,
)
from snapshots import aligned

REPO_ROOT = Path(__file__).resolve().parents[2]
RUNS_DIR = REPO_ROOT / "experiments_reports" / "runs"
# Analyses only; copy the figures the paper uses into the manuscript folder by hand.
OUT_DIRS = [
    REPO_ROOT / "experiments_reports" / "analyses" / "trajectory_cases",
]

TASKS = [
    ("ccna_rip_routing_basic", "RIP"),
    ("troubleshoot_ospf_adjacency_issue", "OSPF adjacency TS"),
    ("ccnp_multiarea_ospf_intermediate", "Multi-area OSPF"),
    ("ccie_bgp_dual_homing_expert", "BGP dual-homing"),
    ("troubleshoot_bgp_route_filtering", "BGP filtering TS"),
]

TASK_GROUPS = [TASKS[:2], TASKS[2:4], TASKS[4:]]
REPEATS_SHOWN = 3  # line styles below distinguish repeat 1 / 2 / 3


def load_runs(runs_dir: Path) -> list[dict[str, Any]]:
    runs = []
    for path in sorted(runs_dir.glob("*/*.json")):
        d = json.loads(path.read_text())
        if d.get("task_id") not in TASK_LABEL or model_of(d) not in M_LABEL:
            continue
        # Empty sessions are kept so they still count as a repeat; they draw no line.
        runs.append(d)
    return runs


def get_token_trajectory(d: dict[str, Any]) -> list[int]:
    """Calculate cumulative tokens at each command step using weighted input+output chars."""
    actions = d.get("actions", [])
    ct = d.get("command_transcript", [])
    total_tokens = ((d.get("metrics") or {}).get("token_usage") or {}).get("total_tokens", 0)

    cum_chars = []
    tot = 0
    for a in actions:
        inp = str(a.get("input", ""))
        res = str(a.get("result", ""))
        tot += len(inp) + len(res)
        cum_chars.append(tot)

    cmd_tokens = []
    curr_act = 0
    for c in ct:
        c_cmd = str(c.get("command", "")).strip()
        matched = False
        for a_idx in range(curr_act, len(actions)):
            a = actions[a_idx]
            if a.get("action") == "exec_command":
                inp = a.get("input")
                a_cmd = str(inp.get("command", "") if isinstance(inp, dict) else inp).strip()
                if a_cmd == c_cmd:
                    ratio = cum_chars[a_idx] / max(tot, 1)
                    cmd_tokens.append(int(round(ratio * total_tokens)))
                    curr_act = a_idx + 1
                    matched = True
                    break
        if not matched:
            step_idx = len(cmd_tokens) + 1
            ratio = step_idx / max(len(ct), 1)
            cmd_tokens.append(int(round(ratio * total_tokens)))

    return cmd_tokens


def plot_trajectory_matrix(
    runs: list[dict[str, Any]],
    tasks: tuple[str, ...],
    family: str,
    axis_type: str,  # 'commands', 'turns', 'tokens'
    group_number: int,
):
    model_ids = {model_of(d) for d in runs}
    styles = ["-", "--", ":"]
    family_models = [m for m in MODELS if m[0] in MODEL_FAMILIES[family] and m[0] in model_ids]
    if not family_models or not tasks:
        return

    n_rows = len(tasks)
    n_cols = len(family_models)
    
    # Generous dimensions so subplots have room and don't collide
    fig, axes = plt.subplots(
        n_rows,
        n_cols,
        figsize=(3.4 * n_cols, 2.6 * n_rows + 1.6),
        sharey="row",
        squeeze=False,
    )

    for i, tid in enumerate(tasks):
        for j, (mid, mlabel, color, _mk) in enumerate(family_models):
            ax = axes[i][j]
            style(ax)
            ax.grid(axis="y", color=GRID, linewidth=0.8)
            ax.grid(axis="x", color=GRID, linewidth=0.5, linestyle=":")

            # First REPEATS_SHOWN runs per model (run_id sorts by date, so these are the
            # earliest repeats); more lines make the panels unreadable.
            mine = sorted(
                [d for d in runs if d["task_id"] == tid and model_of(d) == mid],
                key=lambda d: d["run_id"],
            )[:REPEATS_SHOWN]

            for k, d in enumerate(mine):
                al = aligned(d, classify)
                traj = [a["snapshot"] for a in al]
                if not traj:
                    continue

                if axis_type == "commands":
                    xs = [a["cmd_index"] + 1 for a in al]
                    for a in al:
                        if a["kind"] == "write":
                            ax.plot(
                                a["cmd_index"] + 1,
                                -0.042 + 0.015 * k,
                                marker="|",
                                color=color,
                                markersize=5.0,
                                markeredgewidth=1.3,
                                alpha=0.9,
                                clip_on=False,
                            )
                    terminal_offset = 2
                elif axis_type == "turns":
                    xs = [a["snapshot"].get("turn", a["cmd_index"] + 1) for a in al]
                    for a in al:
                        if a["kind"] == "write":
                            ax.plot(
                                a["snapshot"].get("turn", a["cmd_index"] + 1),
                                -0.042 + 0.015 * k,
                                marker="|",
                                color=color,
                                markersize=5.0,
                                markeredgewidth=1.3,
                                alpha=0.9,
                                clip_on=False,
                            )
                    terminal_offset = 1
                elif axis_type == "tokens":
                    tok_steps = get_token_trajectory(d)
                    xs = [tok_steps[a["cmd_index"]] if a["cmd_index"] < len(tok_steps) else tok_steps[-1] for a in al]
                    for a in al:
                        if a["kind"] == "write":
                            x_val = tok_steps[a["cmd_index"]] if a["cmd_index"] < len(tok_steps) else tok_steps[-1]
                            ax.plot(
                                x_val,
                                -0.042 + 0.015 * k,
                                marker="|",
                                color=color,
                                markersize=5.0,
                                markeredgewidth=1.3,
                                alpha=0.9,
                                clip_on=False,
                            )
                    total_tok = ((d.get("metrics") or {}).get("token_usage") or {}).get("total_tokens", xs[-1] if xs else 0)
                    terminal_offset = max(int(total_tok * 0.03), 500)

                ys = [s["completeness"] for s in traj]
                ax.step(
                    xs,
                    ys,
                    where="post",
                    color=color,
                    linewidth=2.0,
                    linestyle=styles[k % 3],
                    alpha=0.95,
                )

                # Property lost marker
                for x, (a_snap, b_snap) in zip(xs[1:], zip(traj, traj[1:])):
                    if any(v and not b_snap["properties"].get(p) for p, v in a_snap["properties"].items()):
                        ax.plot(
                            x,
                            b_snap["completeness"],
                            marker="x",
                            color=INK,
                            markersize=7.0,
                            markeredgewidth=1.6,
                            zorder=5,
                        )

                term = d["scoring"]["completeness"]
                if axis_type == "tokens":
                    total_tok = ((d.get("metrics") or {}).get("token_usage") or {}).get("total_tokens", xs[-1])
                    terminal_x = max(xs[-1] + terminal_offset, total_tok)
                else:
                    terminal_x = xs[-1] + terminal_offset

                ax.plot(
                    [xs[-1], terminal_x],
                    [ys[-1], term],
                    color=color,
                    linewidth=1.4,
                    linestyle=":",
                    alpha=0.85,
                    zorder=4,
                )
                ax.plot(
                    terminal_x,
                    term,
                    marker="o",
                    color=color,
                    markerfacecolor=color if term >= 1 - 1e-9 else "white",
                    markersize=7.5,
                    markeredgewidth=1.4,
                    zorder=6,
                )

            ax.set_ylim(-0.06, 1.10)
            if i == 0:
                ax.set_title(mlabel, fontsize=12.0, fontweight="bold", color=INK, pad=10)
            if j == 0:
                ax.set_ylabel(f"{TASK_LABEL[tid]}\nFraction of properties met", fontsize=11.0, fontweight="bold", color=INK, labelpad=8)
                ax.tick_params(axis="y", labelsize=10.0, width=1.0, length=4.0)
                for tick in ax.get_yticklabels():
                    tick.set_fontweight("bold")
            else:
                ax.tick_params(axis="y", labelleft=False)

            ax.tick_params(axis="x", labelsize=10.0, width=1.0, length=4.0)
            for tick in ax.get_xticklabels():
                tick.set_fontweight("bold")

            if axis_type == "tokens":
                ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda val, _: f"{int(val/1000)}k" if val >= 1000 else f"{int(val)}"))

            # Only label x on bottom-most row
            if i == len(tasks) - 1:
                if axis_type == "commands":
                    lbl = "Command number (reads included)"
                elif axis_type == "turns":
                    lbl = "Agent turn number"
                else:
                    lbl = "Cumulative tokens"
                ax.set_xlabel(lbl, fontsize=11.0, fontweight="bold", color=INK, labelpad=8)

    semantics = [
        Line2D([], [], color=MUTED, linewidth=2.0, label="per-command snapshot" if axis_type != "turns" else "per-turn snapshot"),
        Line2D([], [], color=MUTED, linewidth=1.4, linestyle=":", label="convergence wait"),
        Line2D([], [], marker="x", color=INK, linestyle="", markersize=7, markeredgewidth=1.6, label="property lost"),
        Line2D([], [], marker="o", color=MUTED, markerfacecolor=MUTED, linestyle="", markersize=7.5, label="end check: C = 1.0"),
        Line2D([], [], marker="o", color=MUTED, markerfacecolor="white", linestyle="", markersize=7.5, markeredgewidth=1.4, label="end check: C < 1.0"),
        Line2D([], [], color=MUTED, linewidth=2.0, linestyle="-", label="repeat 1"),
        Line2D([], [], color=MUTED, linewidth=2.0, linestyle="--", label="repeat 2"),
        Line2D([], [], color=MUTED, linewidth=2.0, linestyle=":", label="repeat 3"),
    ]
    leg = fig.legend(
        handles=semantics,
        loc="upper center",
        ncol=4,
        frameon=False,
        fontsize=10.5,
        bbox_to_anchor=(0.5, 0.99),
        borderaxespad=0.0,
    )
    for text in leg.get_texts():
        text.set_fontweight("bold")

    fig.subplots_adjust(left=0.08, right=0.98, bottom=0.10, top=0.88, hspace=0.25, wspace=0.15)

    base_name = f"figure_trajectory_cases_{family}_{axis_type}_{group_number}"
    for target_dir in OUT_DIRS:
        target_dir.mkdir(parents=True, exist_ok=True)
        pdf_path = target_dir / f"{base_name}.pdf"
        png_path = target_dir / f"{base_name}.png"
        fig.savefig(pdf_path, dpi=300)
        fig.savefig(png_path, dpi=300)
    plt.close(fig)
    print(f"Saved: {base_name}.(pdf|png) to {len(OUT_DIRS)} dirs")


def main():
    runs = load_runs(RUNS_DIR)
    print(f"Loaded {len(runs)} runs from {RUNS_DIR}")

    axes = ["commands", "turns", "tokens"]
    families = ["earlier", "frontier"]

    for family in families:
        for group_idx, group in enumerate(TASK_GROUPS, start=1):
            task_ids = tuple(tid for tid, _ in group)
            for axis in axes:
                plot_trajectory_matrix(
                    runs=runs,
                    tasks=task_ids,
                    family=family,
                    axis_type=axis,
                    group_number=group_idx,
                )

    print("\nAll matrix figures regenerated successfully!")


if __name__ == "__main__":
    main()
