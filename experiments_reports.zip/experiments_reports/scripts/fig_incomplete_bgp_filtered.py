"""Draw the manuscript's BGP dual-homing incomplete-runs figure for a fixed set of runs.

`analyses/sweep/figures/incomplete/fig2_incomplete_ccie_bgp_dual_homing_expert` shows
every incomplete run on the task. The manuscript shows a readable subset instead, so
the caption can say "some of the incomplete runs". The subset is fixed by run id in
SHOWN_RUN_IDS: five incomplete runs from the first three repeats, one per
earlier-generation model plus one frontier run, chosen to show different partial
property patterns.

Output: analyses/case_studies/ (organize_analyses.py then moves it to figures/incomplete/)

Usage:
    poetry run python experiments_reports/scripts/fig_incomplete_bgp_filtered.py
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
sys.path.insert(0, str(HERE))

from analyze_v2_sweep import MODEL_LABELS, PROPERTY_LABELS, TASK_LABELS, model_slug  # noqa: E402

TASK_ID = "ccie_bgp_dual_homing_expert"
DEFAULT_RUNS_DIR = REPO / "experiments_reports" / "runs"
DEFAULT_OUT_DIR = REPO / "experiments_reports" / "analyses" / "case_studies"
PAPER_DIR = Path.home() / "Documents" / "papers" / "benchmark_paper" / "scientific_reports"

# Runs shown in the manuscript figure (all incomplete, all with commands).
SHOWN_RUN_IDS = [
    "openrouter_googlegemini31flashlite_single_mt_20260928_104904_57e6a97c",
    "openrouter_metallamallama3370binstruct_single_mt_20260930_005020_6025498f",
    "openrouter_openaigpt5mini_single_mt_20260930_001632_5cafcb5b",
    "openrouter_qwenqwen3coder30ba3binstruct_single_mt_20260930_005638_49944093",
    "openrouter_qwenqwen3codernext_single_mt_20260930_012528_3ddb1ed7",
]
INK, MUTED = "#1f1f1e", "#6b6b68"
HELD, PALE = "#2b6cb0", "#eef2f7"


def load_incomplete(runs_dir: Path) -> list[dict]:
    rows = []
    for path in sorted((runs_dir / TASK_ID).glob("*.json")):
        data = json.loads(path.read_text())
        if not (data.get("command_transcript") or []):
            continue
        vector = {
            str(item["property_id"]): bool(item.get("satisfied"))
            for item in data.get("property_results") or []
            if item.get("property_id")
        }
        completeness = float((data.get("scoring") or {}).get("completeness") or 0.0)
        if completeness >= 1 - 1e-9:
            continue  # complete runs are not in this figure
        rows.append({
            "run_id": data.get("run_id") or path.stem,
            "model": model_slug(str(data.get("model_version") or "")),
            "completeness": completeness,
            "vector": vector,
        })
    return rows


def select_shown(rows: list[dict]) -> list[dict]:
    by_id = {r["run_id"]: r for r in rows}
    missing = [rid for rid in SHOWN_RUN_IDS if rid not in by_id]
    if missing:
        raise SystemExit(f"runs not found among incomplete runs: {missing}")
    return [by_id[rid] for rid in SHOWN_RUN_IDS]


def draw(rows: list[dict], keys: list[str], out_dir: Path) -> Path:
    fig, ax = plt.subplots(figsize=(7.2, max(1.8, 0.55 * len(rows) + 0.8)))
    for y, row in enumerate(rows):
        for j, key in enumerate(keys):
            held = row["vector"].get(key, False)
            ax.add_patch(plt.Rectangle((j + 0.04, y + 0.08), 0.92, 0.84,
                                       color=HELD if held else PALE, linewidth=0))
            ax.text(j + 0.5, y + 0.5, PROPERTY_LABELS.get(key, key), ha="center", va="center",
                    fontsize=6.5, color="white" if held else MUTED)
    ax.set_xlim(0, len(keys))
    ax.set_ylim(len(rows), 0)
    ax.set_yticks([i + 0.5 for i in range(len(rows))])
    ax.set_yticklabels([f"{MODEL_LABELS.get(r['model'], r['model'])} · C={r['completeness']:.2f}"
                        for r in rows], fontsize=6.7, color=INK)
    ax.set_xticks([])
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)
    fig.subplots_adjust(left=0.31, right=0.99, top=0.99, bottom=0.06)
    target = out_dir / f"fig2_incomplete_{TASK_ID}"
    fig.savefig(target.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(target.with_suffix(".png"), dpi=220, bbox_inches="tight")
    plt.close(fig)
    return target.with_suffix(".pdf")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--runs-dir", type=Path, default=DEFAULT_RUNS_DIR)
    ap.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    ap.add_argument("--paper-dir", type=Path, default=None,
                    help="copy the PDF here if the folder exists")
    args = ap.parse_args()

    rows = load_incomplete(args.runs_dir)
    print(f"incomplete runs on {TASK_ID}: {len(rows)}")
    rows = select_shown(rows)
    rows.sort(key=lambda r: (r["model"], r["completeness"]))
    print(f"shown: {len(rows)}")
    for r in rows:
        print(f"  {MODEL_LABELS.get(r['model'], r['model']):24s} C={r['completeness']:.2f}")

    keys = [p["id"] for p in json.loads(
        (REPO / "tasks" / "multi_turn_v2" / f"{TASK_ID}.json").read_text()
    )["intent"]["properties"]]
    args.out_dir.mkdir(parents=True, exist_ok=True)
    pdf = draw(rows, keys, args.out_dir)
    print(f"wrote {pdf}")
    if args.paper_dir and args.paper_dir.is_dir():
        shutil.copy(pdf, args.paper_dir / pdf.name)
        print(f"copied to {args.paper_dir / pdf.name}")


if __name__ == "__main__":
    main()
