"""Model x property failure matrix: which properties each model fails, per task.

Rows = models, columns = that task's intent properties, cell = share of the model's
runs in which the property is NOT satisfied (failed runs / runs). One panel per task.

Read-only: does not touch the manuscript.

Usage:
    poetry run python experiments_reports/scripts/model_property_matrix.py
    poetry run python experiments_reports/scripts/model_property_matrix.py --models meta-llama/llama-3.3-70b-instruct
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
sys.path.insert(0, str(HERE))

from analyze_v2_sweep import (  # noqa: E402
    MODEL_LABELS,
    MODEL_ORDER,
    PROPERTY_LABELS,
    TASK_LABELS,
    TASK_ORDER,
    model_slug,
)

RUNS_DIR = REPO / "experiments_reports" / "runs"
OUT_DIR = REPO / "experiments_reports" / "analyses" / "rq2_views"
INK, MUTED = "#1f1f1e", "#6b6b68"


def load() -> list[dict]:
    rows = []
    for task_id in TASK_ORDER:
        for path in sorted((RUNS_DIR / task_id).glob("*.json")):
            data = json.loads(path.read_text())
            # Empty sessions (no commands) count: their terminal vector is all-unsatisfied.
            vector = {
                str(item["property_id"]): bool(item.get("satisfied"))
                for item in data.get("property_results") or []
                if item.get("property_id")
            }
            rows.append({
                "task_id": task_id,
                "model": model_slug(str(data.get("model_version") or "")),
                "vector": vector,
            })
    return rows


def matrix(rows: list[dict], task_id: str, models: list[str]) -> tuple[list[str], np.ndarray, np.ndarray]:
    task_rows = [r for r in rows if r["task_id"] == task_id]
    keys = list(task_rows[0]["vector"].keys()) if task_rows else []
    fail = np.full((len(models), len(keys)), np.nan)
    n = np.zeros((len(models), len(keys)), dtype=int)
    for i, m in enumerate(models):
        mrows = [r for r in task_rows if r["model"] == m]
        for j, key in enumerate(keys):
            vals = [r["vector"].get(key) for r in mrows if key in r["vector"]]
            if vals:
                n[i, j] = len(vals)
                fail[i, j] = sum(1 for v in vals if not v) / len(vals)
    return keys, fail, n


def draw(rows: list[dict], models: list[str], path: Path, tasks: list[str] | None = None) -> None:
    cmap = plt.get_cmap("OrRd")
    tasks = tasks or TASK_ORDER
    fig, axes = plt.subplots(len(tasks), 1, figsize=(7.6, 1.35 * len(tasks) + 1.2), squeeze=False)
    for ax, task_id in zip(axes[:, 0], tasks):
        keys, fail, n = matrix(rows, task_id, models)
        for i in range(len(models)):
            for j in range(len(keys)):
                v = fail[i, j]
                if np.isnan(v):
                    ax.add_patch(plt.Rectangle((j + 0.03, i + 0.06), 0.94, 0.88,
                                               color="#f4f4f2", linewidth=0))
                    continue
                ax.add_patch(plt.Rectangle((j + 0.03, i + 0.06), 0.94, 0.88,
                                           color=cmap(0.04 + 0.92 * v), linewidth=0))
                ax.text(j + 0.5, i + 0.5, f"{int(round(v * n[i, j]))}/{n[i, j]}",
                        ha="center", va="center", fontsize=6.5,
                        color="white" if v > 0.6 else INK)
        ax.set_xlim(0, len(keys))
        ax.set_ylim(len(models), 0)
        ax.set_xticks([j + 0.5 for j in range(len(keys))])
        ax.set_xticklabels([PROPERTY_LABELS.get(k, k) for k in keys], fontsize=6.3, color=INK,
                           rotation=16, ha="right", rotation_mode="anchor")
        ax.set_yticks([i + 0.5 for i in range(len(models))])
        ax.set_yticklabels([MODEL_LABELS.get(m, m) for m in models], fontsize=6.8, color=INK)
        ax.tick_params(length=0)
        for spine in ax.spines.values():
            spine.set_visible(False)
        if len(tasks) > 1:
            ax.set_title(TASK_LABELS[task_id], fontsize=8, color=INK, loc="left")
    if len(tasks) > 1:
        fig.suptitle("Properties NOT satisfied per model (failed runs / runs), by task",
                     fontsize=9, color=INK, x=0.02, ha="left")
        fig.tight_layout(rect=(0, 0, 1, 0.97))
    else:
        fig.tight_layout()
    fig.savefig(path.with_suffix(".png"), dpi=220, bbox_inches="tight")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--models", default=None,
                    help="comma-separated model slugs; default = all models in MODEL_ORDER")
    ap.add_argument("--tasks", default=None,
                    help="comma-separated task ids; default = all tasks. Use one task for a single-panel figure.")
    ap.add_argument("--out", default=None,
                    help="output basename (no extension); default = model_property_failure")
    args = ap.parse_args()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    rows = load()
    models = ([m.strip() for m in args.models.split(",")] if args.models
              else [m for m in MODEL_ORDER if any(r["model"] == m for r in rows)])
    tasks = ([t.strip() for t in args.tasks.split(",")] if args.tasks else TASK_ORDER)

    print("=== Properties NOT satisfied per model (failed/runs) ===")
    for task_id in tasks:
        keys, fail, n = matrix(rows, task_id, models)
        print(f"\n{TASK_LABELS[task_id]}")
        print("  " + "model".ljust(22) + "".join(PROPERTY_LABELS.get(k, k)[:12].rjust(14) for k in keys))
        for i, m in enumerate(models):
            line = "  " + MODEL_LABELS.get(m, m).ljust(22)
            for j in range(len(keys)):
                v = fail[i, j]
                line += ("      -" if np.isnan(v) else f"{int(round(v * n[i, j]))}/{n[i, j]}".rjust(14))
            print(line)

    with (OUT_DIR / "model_property_failure.csv").open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["task", "model", "property", "failed", "runs", "failure_share"])
        for task_id in tasks:
            keys, fail, n = matrix(rows, task_id, models)
            for i, m in enumerate(models):
                for j, key in enumerate(keys):
                    if np.isnan(fail[i, j]):
                        continue
                    w.writerow([TASK_LABELS[task_id], MODEL_LABELS.get(m, m),
                                PROPERTY_LABELS.get(key, key), int(round(fail[i, j] * n[i, j])),
                                n[i, j], f"{fail[i, j]:.3f}"])

    out_base = args.out or "model_property_failure"
    draw(rows, models, OUT_DIR / out_base, tasks)
    print(f"\nwrote {OUT_DIR / (out_base + '.png')} and .csv")


if __name__ == "__main__":
    main()
