"""Generate side-by-side trajectory comparison figures for BGP dual-homing.

Generates 6 figures total (2 comparison scenarios x 3 axes):
Option 1 (Partial C = 0.33): Llama 3.3 70B vs Qwen3 Coder 30B
  - fig_trajectory_compare_bgp_partial_commands.(png|pdf)
  - fig_trajectory_compare_bgp_partial_turns.(png|pdf)
  - fig_trajectory_compare_bgp_partial_tokens.(png|pdf)

Option 2 (Complete C = 1.00): GPT-6 Luna vs Qwen3.8 Flash
  - fig_trajectory_compare_bgp_complete_commands.(png|pdf)
  - fig_trajectory_compare_bgp_complete_turns.(png|pdf)
  - fig_trajectory_compare_bgp_complete_tokens.(png|pdf)
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from report_style import style
from analyze_process import INK, MUTED, GRID, classify
from snapshots import aligned

REPO_ROOT = Path(__file__).resolve().parents[2]
RUNS_DIR = REPO_ROOT / "experiments_reports" / "runs" / "ccie_bgp_dual_homing_expert"
OUT_DIRS = [
    REPO_ROOT / "experiments_reports" / "analyses" / "case_studies",
]

# Clean, concise display names for intent properties
PROP_NAMES = {
    "ebgp_isp1_established": "eBGP ISP1",
    "ebgp_isp2_established": "eBGP ISP2",
    "outbound_filtering": "Outbound filter",
    "primary_path_preference": "Local pref (primary)",
    "as_path_prepending": "AS-path prepend",
    "fast_failover_timers": "Failover timers",
}

# Publication colors: Model A (solid Crimson), Model B (dashed Navy)
COLOR_A = "#B22222"  # Crimson
COLOR_B = "#1A365D"  # Deep Navy


def get_token_trajectory(d: dict[str, Any]) -> list[int]:
    """Calculate cumulative tokens at each command step using weighted input+output chars."""
    actions = d.get("actions", [])
    ct = d.get("command_transcript", [])
    total_tokens = (d.get("metrics") or {}).get("token_usage", {}).get("total_tokens", 0)

    cum_chars = []
    tot = 0
    for a in actions:
        inp = str(a.get("input", ""))
        res = str(a.get("result", ""))
        tot += len(inp) + len(res)
        cum_chars.append(tot)

    cmd_tokens = []
    curr_act = 0
    for c in ct:
        c_cmd = str(c.get("command", "")).strip()
        matched = False
        for a_idx in range(curr_act, len(actions)):
            a = actions[a_idx]
            if a.get("action") == "exec_command":
                inp = a.get("input")
                a_cmd = str(inp.get("command", "") if isinstance(inp, dict) else inp).strip()
                if a_cmd == c_cmd:
                    ratio = cum_chars[a_idx] / max(tot, 1)
                    cmd_tokens.append(int(round(ratio * total_tokens)))
                    curr_act = a_idx + 1
                    matched = True
                    break
        if not matched:
            step_idx = len(cmd_tokens) + 1
            ratio = step_idx / max(len(ct), 1)
            cmd_tokens.append(int(round(ratio * total_tokens)))

    return cmd_tokens


def plot_side_by_side_comparison(
    run_a: dict[str, Any],
    label_a: str,
    run_b: dict[str, Any],
    label_b: str,
    axis_type: str,  # 'commands', 'turns', 'tokens'
    title_suffix: str,
    file_stem: str,
    layout_type: str = "complete",  # 'partial' or 'complete'
):
    fig, (ax_a, ax_b) = plt.subplots(
        1, 2, figsize=(11.5, 5.8), sharey=True, gridspec_kw={"wspace": 0.16}
    )

    models_config = [
        (ax_a, run_a, label_a, COLOR_A, "-", "A"),
        (ax_b, run_b, label_b, COLOR_B, "--", "B"),
    ]

    for ax, d, mlabel, color, lstyle, tag in models_config:
        style(ax)
        ax.grid(axis="y", color=GRID, linewidth=0.9, linestyle=":")
        ax.grid(axis="x", color=GRID, linewidth=0.6, linestyle=":")

        al = aligned(d, classify)
        traj = [a["snapshot"] for a in al]
        if not traj:
            continue

        if axis_type == "commands":
            xs = [a["cmd_index"] + 1 for a in al]
            xlabel = "Command number (reads included)"
            terminal_x = xs[-1] + 2
        elif axis_type == "turns":
            xs = [a["snapshot"].get("turn", a["cmd_index"] + 1) for a in al]
            xlabel = "Agent turn number"
            terminal_x = xs[-1] + 1
        elif axis_type == "tokens":
            tok_steps = get_token_trajectory(d)
            xs = [tok_steps[a["cmd_index"]] if a["cmd_index"] < len(tok_steps) else tok_steps[-1] for a in al]
            xlabel = "Cumulative tokens"
            total_tok = (d.get("metrics") or {}).get("token_usage", {}).get("total_tokens", xs[-1] if xs else 0)
            terminal_x = max(xs[-1] + max(int(total_tok * 0.04), 1000), total_tok)

        ys = [s["completeness"] for s in traj]

        # Draw baseline ticks for mutating writes
        for a_step in al:
            if a_step["kind"] == "write":
                if axis_type == "commands":
                    x_tick = a_step["cmd_index"] + 1
                elif axis_type == "turns":
                    x_tick = a_step["snapshot"].get("turn", a_step["cmd_index"] + 1)
                else:
                    x_tick = tok_steps[a_step["cmd_index"]] if a_step["cmd_index"] < len(tok_steps) else tok_steps[-1]
                ax.plot(x_tick, -0.045, marker="|", color=color, markersize=6.0, markeredgewidth=1.8, clip_on=False)

        # Plot trajectory step line
        ax.step(xs, ys, where="post", color=color, linewidth=2.6, linestyle=lstyle, alpha=0.95, zorder=3)

        # Draw terminal convergence segment
        term = d["scoring"]["completeness"]
        ax.plot([xs[-1], terminal_x], [ys[-1], term], color=color, linewidth=1.8, linestyle=":", alpha=0.85, zorder=2)
        ax.plot(
            terminal_x,
            term,
            marker="o",
            color=color,
            markerfacecolor=color if term >= 1 - 1e-9 else "white",
            markersize=9.0,
            markeredgewidth=1.8,
            zorder=5,
        )

        # Collect newly fulfilled property events grouped by step position
        prev_props = {}
        events_by_pos = []  # list of (x_pos, y_pos, [prop_keys])
        for x_pos, s in zip(xs, traj):
            curr_props = s.get("properties") or {}
            newly = [k for k, v in curr_props.items() if v and not prev_props.get(k)]
            lost = [k for k, v in prev_props.items() if v and not curr_props.get(k)]
            if lost:
                ax.plot(x_pos, s["completeness"], marker="x", color=INK, markersize=8.0, markeredgewidth=2.0, zorder=6)
            if newly:
                events_by_pos.append((x_pos, s["completeness"], newly))
            prev_props = curr_props

        max_x = max(xs) if xs else 1

        # Plot events and strictly non-crossing labels
        for idx, (x_pos, y_pos, prop_keys) in enumerate(events_by_pos):
            ax.plot(x_pos, y_pos, marker="o", color=color, markersize=6.5, zorder=5)
            text_lines = [f"+ {PROP_NAMES.get(pk, pk)}" for pk in prop_keys]
            label_text = "\n".join(text_lines)

            if layout_type == "partial":
                if tag == "A":  # Llama (Event 0: failover at y=0.17; Event 1: eBGP ISP1 at y=0.33)
                    if idx == 0:
                        dx, dy, ha = 24, 0, "left"
                    else:
                        dx, dy, ha = -24, 0, "right"
                else:  # Qwen (Event 0: eBGP ISP1 at y=0.17; Event 1: eBGP ISP2 at y=0.33)
                    if idx == 0:
                        dx, dy, ha = -24, 0, "right"
                    else:
                        dx, dy, ha = 24, 0, "left"
            else:  # complete
                if tag == "A":  # GPT-6 Luna
                    config_map = {
                        0: (26, -24, "left"),    # failover
                        1: (26, -18, "left"),    # eBGP ISP1
                        2: (26, 0, "left"),      # eBGP ISP2
                        3: (-26, 0, "right"),    # Outbound filter + Local pref
                        4: (26, -16, "left"),    # AS-path prepend
                    }
                    dx, dy, ha = config_map.get(idx, (26, 0, "left"))
                else:  # Qwen3.8 Flash
                    config_map = {
                        0: (26, -24, "left"),    # failover
                        1: (-26, 16, "right"),   # eBGP ISP1
                        2: (26, 0, "left"),      # eBGP ISP2
                        3: (-26, 0, "right"),    # Outbound filter
                        4: (-26, 0, "right"),    # AS-path prepend
                        5: (-26, 0, "right"),    # Local pref
                    }
                    dx, dy, ha = config_map.get(idx, (26, 0, "left"))

            ax.annotate(
                label_text,
                xy=(x_pos, y_pos),
                xytext=(dx, dy),
                textcoords="offset points",
                ha=ha,
                va="center",
                fontsize=12.0,
                fontweight="bold",
                color=color,
                bbox=dict(
                    boxstyle="round,pad=0.32",
                    facecolor="white",
                    edgecolor=color,
                    alpha=0.95,
                    linewidth=1.2,
                ),
                arrowprops=dict(
                    arrowstyle="->",
                    color=color,
                    linewidth=1.6,
                ),
                zorder=7,
            )

        # Limits with right margin padding to prevent label clipping
        ax.set_ylim(-0.07, 1.07)
        ax.set_yticks([0.0, 0.2, 0.4, 0.6, 0.8, 1.0])
        if axis_type == "tokens":
            ax.set_xlim(-max_x * 0.05, max_x * 1.24)
            ax.xaxis.set_major_formatter(
                plt.FuncFormatter(lambda val, _: f"{int(val/1000)}k" if val >= 1000 else f"{int(val)}")
            )
        else:
            ax.set_xlim(0, max_x * 1.22 + 2.5)

        ax.set_title(f"{mlabel} ({title_suffix})", fontsize=17.0, fontweight="bold", color=INK, pad=12)
        ax.set_xlabel(xlabel, fontsize=15.5, fontweight="bold", color=INK, labelpad=8)
        ax.tick_params(axis="x", labelsize=14.0, width=1.2, length=4.5)
        for tick in ax.get_xticklabels():
            tick.set_fontweight("bold")

    ax_a.set_ylabel("Fraction of properties met ($C$)", fontsize=15.5, fontweight="bold", color=INK, labelpad=8)
    ax_a.tick_params(axis="y", labelsize=14.0, width=1.2, length=4.5)
    for tick in ax_a.get_yticklabels():
        tick.set_fontweight("bold")

    # Subtitle / legend elements
    legend_elements = [
        Line2D([], [], color=COLOR_A, linewidth=2.6, linestyle="-", label=f"{label_a}"),
        Line2D([], [], color=COLOR_B, linewidth=2.6, linestyle="--", label=f"{label_b}"),
        Line2D([], [], marker="|", color=MUTED, linestyle="", markersize=7, markeredgewidth=1.6, label="state change tick"),
        Line2D([], [], color=MUTED, linestyle=":", linewidth=1.8, label="convergence wait"),
        Line2D([], [], marker="o", color=MUTED, markerfacecolor=MUTED, linestyle="", markersize=8.5, label="end check"),
    ]
    leg = fig.legend(
        handles=legend_elements,
        loc="upper center",
        ncol=3,
        frameon=False,
        fontsize=13.5,
        bbox_to_anchor=(0.5, 0.99),
        borderaxespad=0.0,
    )
    for text in leg.get_texts():
        text.set_fontweight("bold")

    fig.subplots_adjust(left=0.09, right=0.96, bottom=0.14, top=0.79, wspace=0.16)

    for target_dir in OUT_DIRS:
        target_dir.mkdir(parents=True, exist_ok=True)
        if target_dir.exists():
            fig.savefig(target_dir / f"{file_stem}.pdf", dpi=300)
            fig.savefig(target_dir / f"{file_stem}.png", dpi=300)

    plt.close(fig)
    print(f"Generated: {file_stem}.(pdf|png)")


def main():
    # Load Option 1: Partial Runs (C = 0.33)
    llama_file = RUNS_DIR / "openrouter_metallamallama3370binstruct_single_mt_20260930_005020_6025498f.json"
    qwen_file = RUNS_DIR / "openrouter_qwenqwen3coder30ba3binstruct_single_mt_20260930_005638_49944093.json"
    run_llama = json.loads(llama_file.read_text())
    run_qwen = json.loads(qwen_file.read_text())

    # Load Option 2: Complete Runs (C = 1.00)
    luna_file = RUNS_DIR / "openrouter_openaigpt6luna_single_mt_20260928_105210_675b60e0.json"
    qwen38_file = RUNS_DIR / "openrouter_qwenqwen38flash_single_mt_20260928_095416_564ada91.json"
    run_luna = json.loads(luna_file.read_text())
    run_qwen38 = json.loads(qwen38_file.read_text())

    axes = ["commands", "turns", "tokens"]

    for ax in axes:
        # Option 1: Partial
        plot_side_by_side_comparison(
            run_a=run_llama,
            label_a="Llama 3.3 70B",
            run_b=run_qwen,
            label_b="Qwen3 Coder 30B",
            axis_type=ax,
            title_suffix="Terminal C = 0.33",
            file_stem=f"fig_trajectory_compare_bgp_partial_{ax}",
            layout_type="partial",
        )

        # Option 2: Complete
        plot_side_by_side_comparison(
            run_a=run_luna,
            label_a="GPT-6 Luna",
            run_b=run_qwen38,
            label_b="Qwen3.8 Flash",
            axis_type=ax,
            title_suffix="Terminal C = 1.00",
            file_stem=f"fig_trajectory_compare_bgp_complete_{ax}",
            layout_type="complete",
        )

    print("\nAll side-by-side comparison figures successfully regenerated!")


if __name__ == "__main__":
    main()
