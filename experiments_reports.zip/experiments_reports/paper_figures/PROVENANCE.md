# Figures used in the NetAgentBench manuscript

Every figure in the manuscript is in this folder. Figure numbers refer to the manuscript version of 2026-10-09.

- **Data figures:** `scripts/run_all_analyses.sh` copies these here from `analyses/` on every rebuild, so they always match the run data in `runs/`.
- **Diagrams:** the files in `diagrams/` are hand-drawn and are not generated from data.

| Fig. | File | What it shows | Produced by | Runs drawn |
|---|---|---|---|---|
| 1 | `fig2_incomplete_ccie_bgp_dual_homing_expert` | Properties held by five incomplete BGP dual-homing runs | `scripts/fig_incomplete_bgp_filtered.py` | The five run ids in `SHOWN_RUN_IDS` in that script. The full set of 47 incomplete runs is in `analyses/sweep/figures/incomplete/`. |
| 2 | `model_property_failure_bgp` | Properties not satisfied per model on BGP dual-homing (failed runs / runs) | `scripts/model_property_matrix.py --tasks ccie_bgp_dual_homing_expert --out model_property_failure_bgp` | All 80 runs of the task, 10 per model |
| 3 | `figure_trajectory_cases_earlier_commands_2` | Per-command state trajectories, earlier-generation models, multi-area OSPF and BGP dual-homing | `scripts/generate_trajectory_variants.py` | First three repeats per model, by run id (date order). A repeat with no command draws no line. |
| 4 | `figure_trajectory_cases_frontier_commands_2` | Same as Fig. 3, frontier models | `scripts/generate_trajectory_variants.py` | First three repeats per model |
| 5 | `fig_trajectory_compare_bgp_partial_tokens` | Property fulfilment over tokens, two partial BGP dual-homing runs with C = 0.33 | `scripts/plot_bgp_route_comparisons.py` | `openrouter_metallamallama3370binstruct_single_mt_20260930_005020_6025498f`, `openrouter_qwenqwen3coder30ba3binstruct_single_mt_20260930_005638_49944093` |
| 6 | `fig_trajectory_compare_bgp_complete_tokens` | Same, two complete BGP dual-homing runs (C = 1.0) | `scripts/plot_bgp_route_comparisons.py` | `openrouter_openaigpt6luna_single_mt_20260928_105210_675b60e0`, `openrouter_qwenqwen38flash_single_mt_20260928_095416_564ada91` |
| 7 | `diagrams/FSM_image.png` | Benchmark architecture | hand-drawn | n/a |
| 8 | `diagrams/e_transition.png` | Event-driven convergence (epsilon transition) | hand-drawn | n/a |
| 9 | `diagrams/containerlab.png` | Implementation on Containerlab | hand-drawn | n/a |

Figures 1 and 3 to 6 show a fixed subset of runs, chosen as case studies. Figure 2 and the tables in `analyses/summary/numbers.md` are computed over all runs (400; the process, cost and replay tables cover the 377 runs that issued at least one command).

The run logs behind every case-study figure (Figs. 1 and 3 to 6) are listed in `case_study_runs.csv`: figure, run id, model, task, terminal C, number of commands, and the path of the run log under `runs/`.
